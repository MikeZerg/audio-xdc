// XDC236 有线无线融合会议系统
#ifndef XDCCONTROLLER_H
#define XDCCONTROLLER_H

#include <QObject>
#include <QString>
#include <QVariantMap>
#include <QDateTime>
#include <QTimer>
#include "ProtocolProcessor.h"

class HostManager;

/* -------------------枚举值------------------------*/
// 数据类别枚举 - 用于区分控制器中不同类型的数据变化
enum class DataType {
    Property,   // 属性数据（版本号、日期等只读状态）
    Setting,    // 设置数据（用户可配置参数，需持久化，如音量、增益）
    Info        // 信息数据（运行时动态信息，如温度、运行时间）
};
Q_DECLARE_METATYPE(DataType)

// 发言模式枚举
enum class SpeechMode {
    FIFO = 0x00,        // 先进先出
    SelfLock = 0x01     // 自锁模式
};
Q_DECLARE_METATYPE(SpeechMode)

// 无线音频路径枚举
enum class WirelessAudioPath {
    Host = 0x00,        // 主机
    AntennaBox = 0x01   // 天线盒
};
Q_DECLARE_METATYPE(WirelessAudioPath)

// 摄像机跟踪协议枚举
enum class CameraProtocol {
    None = 0x00,        // 无
    VISCA = 0x01,       // VISCA协议
    PELCO_D = 0x02,     // PELCO_D协议
    PELCO_P = 0x03      // PELCO_P协议
};
Q_DECLARE_METATYPE(CameraProtocol)

// 摄像机跟踪波特率枚举
enum class CameraBaudrate {
    B2400 = 0x00,       // 2400bps
    B4800 = 0x01,       // 4800bps
    B9600 = 0x02,       // 9600bps
    B115200 = 0x03      // 115200bps
};
Q_DECLARE_METATYPE(CameraBaudrate)
/* -------------------枚举值-----------------------------*/

// 分组1：主机基本属性（6 个基本属性）
struct HostBasicProperties {
    Q_GADGET
    Q_PROPERTY(QString kernelVersion MEMBER kernelVersion)
    Q_PROPERTY(QString linkVersion MEMBER linkVersion)
    Q_PROPERTY(QString antaVersion MEMBER antaVersion)
    Q_PROPERTY(QString kernelDate MEMBER kernelDate)
    Q_PROPERTY(QString linkDate MEMBER linkDate)
    Q_PROPERTY(QString antaDate MEMBER antaDate)

public:
    QString kernelVersion;      // 内核版本（本芯片）
    QString linkVersion;        // 链接版本（Link 芯片）
    QString antaVersion;        // 天线版本（Anta 芯片）
    QString kernelDate;         // 内核编译日期
    QString linkDate;           // 链接编译日期
    QString antaDate;           // 天线编译日期

    void clear() {
        kernelVersion.clear();
        linkVersion.clear();
        antaVersion.clear();
        kernelDate.clear();
        linkDate.clear();
        antaDate.clear();
    }

    QVariantMap toVariantMap() const {
        QVariantMap map;
        map["kernelVersion"] = kernelVersion;
        map["linkVersion"] = linkVersion;
        map["antaVersion"] = antaVersion;
        map["kernelDate"] = kernelDate;
        map["linkDate"] = linkDate;
        map["antaDate"] = antaDate;
        return map;
    }
};

// 分组2：音量相关属性
struct VolumeSettings {
    Q_GADGET
    Q_PROPERTY(uint8_t wirelessVolume MEMBER wirelessVolume)
    Q_PROPERTY(uint8_t wiredVolume MEMBER wiredVolume)
    Q_PROPERTY(uint8_t antennaVolume MEMBER antennaVolume)
    Q_PROPERTY(uint8_t wirelessMaxVolume MEMBER wirelessMaxVolume)
    Q_PROPERTY(uint8_t wiredMaxVolume MEMBER wiredMaxVolume)
    Q_PROPERTY(uint8_t antennaMaxVolume MEMBER antennaMaxVolume)

public:
    uint8_t wirelessVolume = 0;      // 无线音量 Index (0-8，对应实际1-9档)
    uint8_t wiredVolume = 0;         // 有线音量 Index (0-6，对应实际1-7档)
    uint8_t antennaVolume = 0;       // 天线盒音量 Index (0-8，对应实际1-9档)
    uint8_t wirelessMaxVolume = 9;   // 无线最大音量档位数
    uint8_t wiredMaxVolume = 7;      // 有线最大音量档位数
    uint8_t antennaMaxVolume = 9;    // 天线盒最大音量档位数
};

// 分组3：发言相关属性
struct SpeechSettings {
    Q_GADGET
    Q_PROPERTY(SpeechMode speechMode MEMBER speechMode)
    Q_PROPERTY(uint8_t maxSpeechCount MEMBER maxSpeechCount)
    Q_PROPERTY(uint8_t hardwareMaxSpeech MEMBER hardwareMaxSpeech)
    Q_PROPERTY(uint16_t currentWirelessSpeakerId MEMBER currentWirelessSpeakerId)
    Q_PROPERTY(uint16_t currentWiredSpeakerId MEMBER currentWiredSpeakerId)
    Q_PROPERTY(WirelessAudioPath wirelessAudioPath MEMBER wirelessAudioPath)

public:
    SpeechMode speechMode = SpeechMode::FIFO;           // 发言模式
    uint8_t maxSpeechCount = 1;                         // 最大发言人数
    uint8_t hardwareMaxSpeech = 4;                      // 硬件最大发言人数
    uint16_t currentWirelessSpeakerId = 0;              // 当前无线发言ID
    uint16_t currentWiredSpeakerId = 0;                 // 当前有线发言ID
    WirelessAudioPath wirelessAudioPath = WirelessAudioPath::Host;  // 无线音频路径
};

// 分组4：摄像跟踪相关属性
struct CameraSettings {
    Q_GADGET
    Q_PROPERTY(CameraProtocol protocol MEMBER protocol)
    Q_PROPERTY(uint8_t address MEMBER address)
    Q_PROPERTY(CameraBaudrate baudrate MEMBER baudrate)

public:
    CameraProtocol protocol = CameraProtocol::None;     // 摄像跟踪协议
    uint8_t address = 1;                                // 摄像跟踪地址
    CameraBaudrate baudrate = CameraBaudrate::B9600;    // 摄像跟踪波特率
};


// XDC 主机控制器 - 负责控制单个 XDC236 主机
class XdcController : public QObject
{
    Q_OBJECT

    Q_PROPERTY(bool stateValid READ isStateValid NOTIFY dataChanged)  // 暴露状态标记

    Q_PROPERTY(uint8_t address READ address CONSTANT FINAL)           // 主机地址（只读）
    Q_PROPERTY(HostBasicProperties hostProperties READ getHostBasicProperties NOTIFY dataChanged)  // 通过统一信号通知
    Q_PROPERTY(VolumeSettings volumeSettings READ getVolumeSettings NOTIFY dataChanged)
    Q_PROPERTY(SpeechSettings speechSettings READ getSpeechSettings NOTIFY dataChanged)
    Q_PROPERTY(CameraSettings cameraSettings READ getCameraSettings NOTIFY dataChanged)
    Q_PROPERTY(QDateTime systemDateTime MEMBER m_systemDateTime NOTIFY systemDateTimeUpdated)


public:
    explicit XdcController(uint8_t hostAddress, HostManager* parent);
    virtual ~XdcController();

    // 状态导出/导入 - 用于切换保存/恢复
    QVariantMap exportState() const;
    void importState(const QVariantMap& state);

    // 发送指令函数
    Q_INVOKABLE QVariantList createGetQueue(const QVariantList& commands);  // 生成批量“查询指令集”
    Q_INVOKABLE QVariantList createSetQueue(const QVariantList& commands);  // 生成批量“设置指令集”

    void sendToHost(const QByteArray& data);        // 发送指令到主机
    Q_INVOKABLE void sendCommand(uint8_t opCode, uint16_t command, const QByteArray& payload = QByteArray(),
                                 const QVariant& userData = QVariant());  // 构建并发送单个指令
    Q_INVOKABLE void sendCommandQueue(const QVariantList& commands);  // 批量发送指令队列
    // 接收指令分发函数
    void handleIncomingFrame(const ProtocolProcessor::ParsedFrameData& frame);  // 处理接收到的指令帧

    Q_INVOKABLE void getBasicProperties();          // 初始化主机属性（批量获取 6 个基本属性）这个似乎可以删除？？？

    // ======= 辅助函数 =======
    QString formatAddressHex(uint8_t address) { return QString::asprintf("0x%02X", address); }

    // Getter
    bool isStateValid() const { return m_stateValid; }                 // 状态有效性标记

    uint8_t address() const { return m_hostAddress; }
    HostBasicProperties getHostBasicProperties() const { return m_hostProperties; }
    VolumeSettings getVolumeSettings() const { return m_volumeSettings; }
    SpeechSettings getSpeechSettings() const { return m_speechSettings; }
    CameraSettings getCameraSettings() const { return m_cameraSettings; }
    QDateTime getSystemDateTime() const { return m_systemDateTime; }

    // ========== 分组2：音量相关接口 ==========
    Q_INVOKABLE void getWirelessVolume();           // 获取无线音量
    Q_INVOKABLE void setWirelessVolume(uint8_t index);  // 设置无线音量 (0-8)
    Q_INVOKABLE void getWiredVolume();              // 获取有线音量
    Q_INVOKABLE void setWiredVolume(uint8_t index);     // 设置有线音量 (0-6)
    Q_INVOKABLE void getAntennaVolume();            // 获取天线盒音量
    Q_INVOKABLE void setAntennaVolume(uint8_t index);   // 设置天线盒音量 (0-8)

    // ========== 分组3：发言相关接口 ==========
    Q_INVOKABLE void getSpeechMode();               // 获取发言模式
    Q_INVOKABLE void setSpeechMode(uint8_t mode);   // 设置发言模式 (0=FIFO, 1=SelfLock)
    Q_INVOKABLE void getMaxSpeechCount();           // 获取最大发言数量
    Q_INVOKABLE void setMaxSpeechCount(uint8_t count);  // 设置最大发言数量 (1-4)
    Q_INVOKABLE void getCurrentWirelessSpeakerId(); // 获取当前无线发言ID
    Q_INVOKABLE void getCurrentWiredSpeakerId();    // 获取当前有线发言ID
    Q_INVOKABLE void getWirelessAudioPath();        // 获取无线音频路径
    Q_INVOKABLE void setWirelessAudioPath(uint8_t path);    // 设置无线音频路径 (0=主机, 1=天线盒)

    // ========== 分组4：摄像跟踪相关接口 ==========
    Q_INVOKABLE void getCameraProtocol();           // 获取摄像跟踪协议
    Q_INVOKABLE void setCameraProtocol(uint8_t protocol);   // 设置摄像跟踪协议 (0=None, 1=VISCA, 2=PELCO_D, 3=PELCO_P)
    Q_INVOKABLE void getCameraAddress();            // 获取摄像跟踪地址
    Q_INVOKABLE void setCameraAddress(uint8_t address);     // 设置摄像跟踪地址
    Q_INVOKABLE void getCameraBaudrate();           // 获取摄像跟踪波特率
    Q_INVOKABLE void setCameraBaudrate(uint8_t baudrate);   // 设置摄像跟踪波特率 (0=2400,1=4800,2=9600,3=115200)

    // ========== 分组7：系统时间接口 ==========
    Q_INVOKABLE void getSystemDateTime();                   // 获取系统时间
    Q_INVOKABLE void setSystemDateTime(uint32_t utcTime);   // 设置系统时间 (UTC时间戳)


signals:
    // 批量数据更新信号 - 用于减少信号开销
    void dataBatchUpdated(uint8_t address, DataType type, const QVariantMap& data);
    // 完整状态快照信号 - 用于切换保存/恢复
    void stateSnapshot(uint8_t address, const QVariantMap& snapshot);
    // 切换生命周期信号
    void aboutToDeactivate(uint8_t address);        // 即将停用 - 切换前由 HostManager 触发
    void activated(uint8_t address);                // 已激活 - 切换后由 HostManager 触发

    // 操作执行结果信号
    void operationResult(uint8_t address, const QString& operation, bool success, const QString& message);
    // 保留的兼容信号
    void commandFailed(uint16_t command, const QString& error);  // 命令执行失败信号

    // 统一的数据变化信号 - 通过 DataType 枚举区分数据类型
    void dataChanged(uint8_t address, DataType type, const QString& name, const QVariant& value);
    // 系统时间信号
    void systemDateTimeUpdated(uint8_t address, const QDateTime& dateTime);
    // 当前发言ID更新信号
    void currentSpeakerIdUpdated(uint8_t address, const QString& type, uint16_t speakerId);


private slots:
    void onCommandResponseCompleted(const ProtocolProcessor::ResponseResult& result);  // 响应完成处理
    void onCommandFailed(const ProtocolProcessor::PendingRequest& request, const QString& error);  // 请求失败处理

private:
    // 成员变量
    uint8_t m_hostAddress;                          // 主机地址
    HostManager* m_hostManager;                     // 主机管理器
    ProtocolProcessor* m_protocolProcessor;         // 协议处理器

    int m_pendingResponses = 0;                     // 已接收响应计数（Request-Response）
    int m_expectedResponses = 0;                    // 期望响应总数（Request-Response）

    bool m_stateValid = false;                      // 状态有效性标记

    HostBasicProperties m_hostProperties;           // 主机基本属性
    VolumeSettings m_volumeSettings;                // 音量设置
    SpeechSettings m_speechSettings;                // 发言设置
    CameraSettings m_cameraSettings;                // 摄像跟踪设置
    QDateTime m_systemDateTime;                     // 系统时间

    // 私有方法
    void setupProtocolProcessor();                  // 设置协议处理器
    void parseAndDispatch(const ProtocolProcessor::ParsedFrameData& frame);  // 解析并分发响应数据
    void handleSetResponse(const ProtocolProcessor::ParsedFrameData& frame, const QString& operation);  // 通用设置响应处理

    // 辅助方法，处理多主机切换时数据保存与加载
    void notifyDataChange(DataType type, const QString& name, const QVariant& value);  // 统一的信号发射辅助方法
    void notifyBatchDataUpdate(DataType type, const QVariantMap& data);  // 通知批量数据更新
    void notifyStateSnapshot();                     // 通知完整状态快照
    void checkAllPropertiesLoaded();                // 检查并标记所有属性加载完成

    // 分组1：主机基本属性（不变）
    void handleVersionResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleBuildDateResponse(const ProtocolProcessor::ParsedFrameData& frame);

    // 分组2：音量响应处理（可设置）
    void handleWirelessVolumeResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleWiredVolumeResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleAntennaVolumeResponse(const ProtocolProcessor::ParsedFrameData& frame);

    // 分组3：发言相关响应处理（可设置）
    void handleSpeechModeResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleMaxSpeechCountResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleCurrentWirelessSpeakerIdResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleCurrentWiredSpeakerIdResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleWirelessAudioPathResponse(const ProtocolProcessor::ParsedFrameData& frame);

    // 分组4：摄像跟踪响应处理（可设置）
    void handleCameraProtocolResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleCameraAddressResponse(const ProtocolProcessor::ParsedFrameData& frame);
    void handleCameraBaudrateResponse(const ProtocolProcessor::ParsedFrameData& frame);

    // 分组7：系统时间响应处理（可设置）
    void handleSystemDateTimeResponse(const ProtocolProcessor::ParsedFrameData& frame);
};

#endif // XDCCONTROLLER_H