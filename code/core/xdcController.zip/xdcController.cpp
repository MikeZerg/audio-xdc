// XDC236 有线无线融合会议系统
#include "xdcController.h"
#include "HostManager.h"
#include "ProtocolProcessor.h"
#include <QDebug>
#include <QDateTime>

// ==================== 构造函数 ====================
XdcController::XdcController(uint8_t hostAddress, HostManager* parent)
    : QObject(parent)
    , m_hostAddress(hostAddress)
    , m_hostManager(parent)
    , m_protocolProcessor(new ProtocolProcessor(this))
{
    qDebug() << "XdcController：构造地址："
             << QString("0x%1").arg(m_hostAddress, 2, 16, QChar('0')).toUpper();

    setupProtocolProcessor();
}

XdcController::~XdcController()
{
    qDebug() << "XdcController：析构地址："
             << QString("0x%1").arg(m_hostAddress, 2, 16, QChar('0')).toUpper();
}

// ==================== 切换数据实现 ====================
QVariantMap XdcController::exportState() const
{
    QVariantMap state;

    // 分组1：主机基本属性
    state["kernelVersion"] = m_hostProperties.kernelVersion;
    state["linkVersion"] = m_hostProperties.linkVersion;
    state["antaVersion"] = m_hostProperties.antaVersion;
    state["kernelDate"] = m_hostProperties.kernelDate;
    state["linkDate"] = m_hostProperties.linkDate;
    state["antaDate"] = m_hostProperties.antaDate;

    // 分组2：音量设置
    state["wirelessVolume"] = m_volumeSettings.wirelessVolume;
    state["wiredVolume"] = m_volumeSettings.wiredVolume;
    state["antennaVolume"] = m_volumeSettings.antennaVolume;

    // 分组3：发言设置
    state["speechMode"] = static_cast<uint8_t>(m_speechSettings.speechMode);
    state["maxSpeechCount"] = m_speechSettings.maxSpeechCount;
    state["wirelessAudioPath"] = static_cast<uint8_t>(m_speechSettings.wirelessAudioPath);
    state["currentWirelessSpeakerId"] = m_speechSettings.currentWirelessSpeakerId;
    state["currentWiredSpeakerId"] = m_speechSettings.currentWiredSpeakerId;

    // 分组4：摄像跟踪设置
    state["cameraProtocol"] = static_cast<uint8_t>(m_cameraSettings.protocol);
    state["cameraAddress"] = m_cameraSettings.address;
    state["cameraBaudrate"] = static_cast<uint8_t>(m_cameraSettings.baudrate);

    // 分组7：系统时间
    state["systemDateTime"] = m_systemDateTime.toString(Qt::ISODate);

    // 添加元数据
    state["_address"] = m_hostAddress;
    state["_timestamp"] = QDateTime::currentDateTime().toString(Qt::ISODate);
    state["_version"] = "1.0";

    return state;
}

void XdcController::importState(const QVariantMap& state)
{
    // 验证地址
    if (state.contains("_address")) {
        uint8_t savedAddress = state["_address"].toUInt();
        if (savedAddress != m_hostAddress) {
            qWarning().noquote() << QString("XdcController：状态地址不匹配！期望：%1，实际：%2")
                                        .arg(formatAddressHex(m_hostAddress), formatAddressHex(savedAddress));
        }
    }

    // 恢复属性
    if (state.contains("kernelVersion"))
        m_hostProperties.kernelVersion = state["kernelVersion"].toString();
    if (state.contains("linkVersion"))
        m_hostProperties.linkVersion = state["linkVersion"].toString();
    if (state.contains("antaVersion"))
        m_hostProperties.antaVersion = state["antaVersion"].toString();
    if (state.contains("kernelDate"))
        m_hostProperties.kernelDate = state["kernelDate"].toString();
    if (state.contains("linkDate"))
        m_hostProperties.linkDate = state["linkDate"].toString();
    if (state.contains("antaDate"))
        m_hostProperties.antaDate = state["antaDate"].toString();

    m_stateValid = true;

    // 通知所有属性变化（批量通知）
    QVariantMap allProps;
    allProps["kernelVersion"] = m_hostProperties.kernelVersion;
    allProps["linkVersion"] = m_hostProperties.linkVersion;
    allProps["antaVersion"] = m_hostProperties.antaVersion;
    allProps["kernelDate"] = m_hostProperties.kernelDate;
    allProps["linkDate"] = m_hostProperties.linkDate;
    allProps["antaDate"] = m_hostProperties.antaDate;
    notifyBatchDataUpdate(DataType::Property, allProps);

    qDebug().noquote() << QString("XdcController：状态恢复完成，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
}

// ==================== 初始化协议处理器 ====================
void XdcController::setupProtocolProcessor()
{
    // 1. 设置发送函数（注入硬件发送能力）
    m_protocolProcessor->setSendFunction([this](const QByteArray& data) {
        sendToHost(data);
    });

    // 2. 配置通信参数
    m_protocolProcessor->setResponseTimeout(500);   // 500ms 超时
    m_protocolProcessor->setMaxRetries(3);          // 最多重试 3 次
    m_protocolProcessor->setInterCommandDelay(50);  // 指令间隔 50ms

    // 3. 连接信号槽
    connect(m_protocolProcessor, &ProtocolProcessor::responseCompleted,
            this, &XdcController::onCommandResponseCompleted);
    connect(m_protocolProcessor, &ProtocolProcessor::requestFailed,
            this, &XdcController::onCommandFailed);
}

// ==================== 通用发送功能 ====================
/* 创建批量“查询指令集” */
QVariantList XdcController::createGetQueue(const QVariantList& commands)
{
    QVariantList queue;

    for (const auto& cmdVariant : commands) {
        QVariantMap cmd = cmdVariant.toMap();

        // 获取命令码
        if (!cmd.contains("command")) {
            qWarning() << "createGetQueue: 命令缺少 command 字段";
            continue;
        }

        uint16_t command = cmd["command"].toUInt();
        QByteArray payload;

        // 如果有 payload 字段则使用
        if (cmd.contains("payload")) {
            payload = cmd["payload"].toByteArray();
        }

        // 操作名称，用于回调标识
        QString operation = cmd.value("operation", QString("get_0x%1").arg(command, 4, 16, QChar('0'))).toString();

        QVariantMap request;
        request["opCode"] = static_cast<uint8_t>(0x01);  // 请求操作码
        request["command"] = command;
        request["payload"] = payload;
        request["userData"] = operation;

        queue.append(request);
    }

    qDebug().noquote() << QString("XdcController: 生成获取指令队列，地址：%1，数量：%2")
                              .arg(formatAddressHex(m_hostAddress))
                              .arg(queue.size());

    return queue;
}
/* 创建批量“设置指令集” */
QVariantList XdcController::createSetQueue(const QVariantList& commands)
{
    QVariantList queue;

    for (const auto& cmdVariant : commands) {
        QVariantMap cmd = cmdVariant.toMap();

        // 获取命令码和负载
        if (!cmd.contains("command")) {
            qWarning() << "createSetQueue: 命令缺少 command 字段";
            continue;
        }

        if (!cmd.contains("payload")) {
            qWarning() << "createSetQueue: 设置命令缺少 payload 字段";
            continue;
        }

        uint16_t command = cmd["command"].toUInt();
        QByteArray payload = cmd["payload"].toByteArray();

        // 操作名称，用于回调标识
        QString operation = cmd.value("operation", QString("set_0x%1").arg(command, 4, 16, QChar('0'))).toString();

        QVariantMap request;
        request["opCode"] = static_cast<uint8_t>(0x01);  // 请求操作码
        request["command"] = command;
        request["payload"] = payload;
        request["userData"] = operation;

        queue.append(request);
    }

    qDebug().noquote() << QString("XdcController: 生成设置指令队列，地址：%1，数量：%2")
                              .arg(formatAddressHex(m_hostAddress))
                              .arg(queue.size());

    return queue;
}

void XdcController::sendToHost(const QByteArray& data)
{
    if (m_hostManager) {
        m_hostManager->sendRawData(data);
    } else {
        qWarning().noquote() << QString("XdcController：HostManager为空，无法发送数据");
    }
}

void XdcController::sendCommand(uint8_t opCode, uint16_t command,
                                const QByteArray& payload,
                                const QVariant& userData)
{
    ProtocolProcessor::CommandConfig config(
        m_hostAddress,      // 目标地址
        0x80,               // 源地址
        opCode,             // 操作码
        command,            // 命令码
        payload             // 负载
        );

    m_protocolProcessor->sendCommand(config, -1, userData);
}

void XdcController::sendCommandQueue(const QVariantList& commandQueue)
{
    QVector<ProtocolProcessor::PendingRequest> requests;

    for (const auto& cmdVariant : commandQueue) {
        QVariantMap cmd = cmdVariant.toMap();

        uint8_t opCode = cmd["opCode"].toUInt();
        uint16_t command = cmd["command"].toUInt();
        QByteArray payload = cmd["payload"].toByteArray();
        QString userData = cmd["userData"].toString();

        ProtocolProcessor::PendingRequest req;
        req.commandConfig = ProtocolProcessor::CommandConfig(
            m_hostAddress, 0x80, opCode, command, payload
            );
        req.rawFrame = ProtocolProcessor::buildFrame(
            req.commandConfig.destAddr, req.commandConfig.srcAddr,
            req.commandConfig.opCode, req.commandConfig.command,
            req.commandConfig.payload
            );
        req.matchRule = ProtocolProcessor::MatchRule::fromCommandConfig(req.commandConfig);
        req.maxRetries = 3;
        req.userData = QVariant(userData);

        requests.append(req);
    }

    m_protocolProcessor->sendCommandQueue(requests);
}

// ==================== 通用回调处理 ====================
void XdcController::onCommandResponseCompleted(const ProtocolProcessor::ResponseResult& result)
{
    if (!result.success) {
        qWarning().noquote() << QString("XdcController：响应失败：%1").arg(result.errorMessage);
        return;
    }

    parseAndDispatch(result.parsedData);
}

void XdcController::onCommandFailed(const ProtocolProcessor::PendingRequest& request,
                                    const QString& error)
{
    qWarning().noquote() << QString("XdcController：指令执行失败：%1，用户数据：%2，CMD：0x%3")
                                .arg(error, request.userData.toString(), QString::number(request.commandConfig.command, 16));

    emit commandFailed(request.commandConfig.command, error);

    QString operation = request.userData.toString();
    emit operationResult(m_hostAddress, operation, false, error);
}

// ==================== 数据接收、解析和分发 ====================
void XdcController::handleIncomingFrame(const ProtocolProcessor::ParsedFrameData& frame)
{
    qDebug().noquote() << QString("XdcController：收到HostManager转发数据，地址：%1，CMD：0x%2，负载：%3")
                              .arg(formatAddressHex(m_hostAddress),
                                   QString::number(frame.command, 16).toUpper().rightJustified(4, '0'),
                                   QString(frame.payload.toHex(' ').toUpper()));


    // 构建原始帧交给 ProtocolProcessor 处理
    QByteArray rawFrame = ProtocolProcessor::buildFrame(
        frame.destAddr,
        frame.srcAddr,
        frame.opCode,
        frame.command,
        frame.payload
        );

    m_protocolProcessor->handleIncomingFrame(rawFrame);
}

void XdcController::parseAndDispatch(const ProtocolProcessor::ParsedFrameData& frame)
{
    switch (frame.command) {
    // 分组1：基本属性
    case 0x0202: handleVersionResponse(frame); break;      // 版本号
    case 0x0203: handleBuildDateResponse(frame); break;    // 编译日期

    // 分组2：音量
    case 0x0205: handleWirelessVolumeResponse(frame); break;    // 无线音量
    case 0x0206: handleWiredVolumeResponse(frame); break;       // 有线音量
    case 0x0207: handleAntennaVolumeResponse(frame); break;     // 天线盒音量

    // 分组3：发言相关
    case 0x0208: handleSpeechModeResponse(frame); break;
    case 0x0209: handleMaxSpeechCountResponse(frame); break;
    case 0x020E: handleCurrentWirelessSpeakerIdResponse(frame); break;
    case 0x020F: handleCurrentWiredSpeakerIdResponse(frame); break;
    case 0x020D: handleWirelessAudioPathResponse(frame); break;

    // 分组4：摄像跟踪
    case 0x020A: handleCameraProtocolResponse(frame); break;
    case 0x020B: handleCameraAddressResponse(frame); break;
    case 0x020C: handleCameraBaudrateResponse(frame); break;

    // 分组7：系统时间
    case 0x0204: handleSystemDateTimeResponse(frame); break;

    // 设置命令的响应 (操作码0x01的响应是0x04)
        // 设置命令的响应 - 根据具体命令传递操作名称
    case 0x0105:  // 设置无线音量响应
        handleSetResponse(frame, "setWirelessVolume");
        break;
    case 0x0106:  // 设置有线音量响应
        handleSetResponse(frame, "setWiredVolume");
        break;
    case 0x0107:  // 设置天线盒音量响应
        handleSetResponse(frame, "setAntennaVolume");
        break;
    case 0x0108:  // 设置发言模式响应
        handleSetResponse(frame, "setSpeechMode");
        break;
    case 0x0109:  // 设置最大发言数量响应
        handleSetResponse(frame, "setMaxSpeechCount");
        break;
    case 0x010D:  // 设置无线音频路径响应
        handleSetResponse(frame, "setWirelessAudioPath");
        break;
    case 0x010A:  // 设置摄像跟踪协议响应
        handleSetResponse(frame, "setCameraProtocol");
        break;
    case 0x010B:  // 设置摄像跟踪地址响应
        handleSetResponse(frame, "setCameraAddress");
        break;
    case 0x010C:  // 设置摄像跟踪波特率响应
        handleSetResponse(frame, "setCameraBaudrate");
        break;
    case 0x0104:  // 设置系统时间响应
        handleSetResponse(frame, "setSystemDateTime");
        break;

    default:
        qWarning().noquote() << QString("XdcController：未知命令：0x%1")
                                    .arg(QString::number(frame.command, 16));
    }
}

// ==================== 辅助方法 ====================
void XdcController::notifyDataChange(DataType type, const QString& name, const QVariant& value)
{
    emit dataChanged(m_hostAddress, type, name, value);  // 统一数据变化信号

    QString typeStr = (type == DataType::Property) ? "Property" :
                          (type == DataType::Setting) ? "Setting" : "Info";
    qDebug().noquote() << QString("XdcController：数据变化 - [%1] %2 = %3")
                              .arg(typeStr, name, value.toString());
}

void XdcController::notifyBatchDataUpdate(DataType type, const QVariantMap& data)
{
    emit dataBatchUpdated(m_hostAddress, type, data);
}

void XdcController::notifyStateSnapshot()
{
    emit stateSnapshot(m_hostAddress, exportState());
}

void XdcController::checkAllPropertiesLoaded()
{
    m_pendingResponses++;
    if (m_pendingResponses >= m_expectedResponses) {
        m_stateValid = true;
        notifyStateSnapshot();  // 所有属性加载完成，发射完整状态快照
        qDebug().noquote() << QString("XdcController：所有属性加载完成，地址：%1")
                                  .arg(formatAddressHex(m_hostAddress));
    }
}

// ==================== 主机操控功能-读取属性 ====================
void XdcController::getBasicProperties()
{
    qDebug().noquote() << QString("XdcController: 开始批量获取主机基本属性，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));

    // 清空之前的数据
    m_hostProperties.clear();
    m_stateValid = false;
    m_pendingResponses = 0;     //未接收到的响应个数
    m_expectedResponses = 6;    // 期望接收6个响应

    // 批量发送 6 个指令获取基本属性
    QVector<ProtocolProcessor::PendingRequest> requests;

    auto createRequest = [&](uint16_t cmd, const QByteArray& payload,
                             const QString& userData) -> ProtocolProcessor::PendingRequest {
        ProtocolProcessor::PendingRequest req;
        req.commandConfig = ProtocolProcessor::CommandConfig(
            m_hostAddress, 0x80, 0x01, cmd, payload
            );
        req.rawFrame = ProtocolProcessor::buildFrame(
            req.commandConfig.destAddr, req.commandConfig.srcAddr,
            req.commandConfig.opCode, req.commandConfig.command,
            req.commandConfig.payload
            );
        req.matchRule = ProtocolProcessor::MatchRule::fromCommandConfig(req.commandConfig);
        req.maxRetries = 3;
        req.userData = QVariant(userData);
        return req;
    };

    // 添加 6 个请求（3 个版本 + 3 个日期）
    requests.append(createRequest(0x0202, QByteArray(1, '\x00'), "version_kernel"));   // 本芯片版本
    requests.append(createRequest(0x0202, QByteArray(1, '\x01'), "version_link"));     // Link 芯片版本
    requests.append(createRequest(0x0202, QByteArray(1, '\x02'), "version_anta"));     // Anta 芯片版本
    requests.append(createRequest(0x0203, QByteArray(1, '\x00'), "date_kernel"));      // 本芯片日期
    requests.append(createRequest(0x0203, QByteArray(1, '\x01'), "date_link"));        // Link 芯片日期
    requests.append(createRequest(0x0203, QByteArray(1, '\x02'), "date_anta"));        // Anta 芯片日期

    // 批量发送
    m_protocolProcessor->sendCommandQueue(requests);
}

// ==================== 分组1：属性数据处理函数 ====================
void XdcController::handleVersionResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.isEmpty()) return;

    quint8 subCmd = static_cast<quint8>(frame.payload.at(0));
    QString version = QString::fromUtf8(frame.payload.mid(1));

    if (subCmd == 0x00) {
        m_hostProperties.kernelVersion = version;
        notifyDataChange(DataType::Property, "kernelVersion", version);
        qDebug().noquote() << QString("XdcController：内核版本：%1").arg(version);
    }
    else if (subCmd == 0x01) {
        m_hostProperties.linkVersion = version;
        notifyDataChange(DataType::Property, "linkVersion", version);
        qDebug().noquote() << QString("XdcController：链接版本：%1").arg(version);
    }
    else if (subCmd == 0x02) {
        m_hostProperties.antaVersion = version;
        notifyDataChange(DataType::Property, "antaVersion", version);
        qDebug().noquote() << QString("XdcController：天线版本：%1").arg(version);
    }

    checkAllPropertiesLoaded();

    qDebug().noquote() << QString("XdcController：[版本属性更新] 内核：%1 | Link：%2 | Anta：%3")
                              .arg(m_hostProperties.kernelVersion,
                                   m_hostProperties.linkVersion,
                                   m_hostProperties.antaVersion);
}

void XdcController::handleBuildDateResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.isEmpty()) return;

    quint8 subCmd = static_cast<quint8>(frame.payload.at(0));
    QString date = QString::fromUtf8(frame.payload.mid(1));

    if (subCmd == 0x00) {
        m_hostProperties.kernelDate = date;
        notifyDataChange(DataType::Property, "kernelDate", date);
        qDebug().noquote() << QString("XdcController：内核编译日期：%1").arg(date);
    }
    else if (subCmd == 0x01) {
        m_hostProperties.linkDate = date;
        notifyDataChange(DataType::Property, "linkDate", date);
        qDebug().noquote() << QString("XdcController：链接编译日期：%1").arg(date);
    }
    else if (subCmd == 0x02) {
        m_hostProperties.antaDate = date;
        notifyDataChange(DataType::Property, "antaDate", date);
        qDebug().noquote() << QString("XdcController：天线编译日期：%1").arg(date);
    }

    checkAllPropertiesLoaded();

    qDebug().noquote() << QString("XdcController：[日期属性更新] 内核：%1 | Link：%2 | Anta：%3")
                              .arg(m_hostProperties.kernelDate,
                                   m_hostProperties.linkDate,
                                   m_hostProperties.antaDate);
}

// ==================== 分组2：音量相关功能 ====================
void XdcController::getWirelessVolume()
{
    qDebug().noquote() << QString("XdcController: 获取无线音量，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x0205, QByteArray(), "getWirelessVolume");
}

void XdcController::setWirelessVolume(uint8_t index)
{
    if (index >= m_volumeSettings.wirelessMaxVolume) {
        qWarning() << "无线音量索引超出范围，最大值:" << m_volumeSettings.wirelessMaxVolume - 1;
        emit operationResult(m_hostAddress, "setWirelessVolume", false, "音量索引超出范围");
        return;
    }

    qDebug().noquote() << QString("XdcController: 设置无线音量，地址：%1，索引：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(index);
    QByteArray payload;
    payload.append(static_cast<char>(index));
    sendCommand(0x01, 0x0105, payload, "setWirelessVolume");
}

void XdcController::handleWirelessVolumeResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.size() < 2) {
        qWarning() << "无线音量响应数据长度不足";
        return;
    }

    uint8_t currentIndex = static_cast<uint8_t>(frame.payload.at(0));
    uint8_t maxCount = static_cast<uint8_t>(frame.payload.at(1));

    m_volumeSettings.wirelessVolume = currentIndex;
    m_volumeSettings.wirelessMaxVolume = maxCount;

    notifyDataChange(DataType::Setting, "wirelessVolume", currentIndex);
    notifyDataChange(DataType::Info, "wirelessMaxVolume", maxCount);

    qDebug().noquote() << QString("XdcController：无线音量：当前索引=%1，最大档位=%2")
                              .arg(currentIndex).arg(maxCount);
}

void XdcController::getWiredVolume()
{
    qDebug().noquote() << QString("XdcController: 获取有线音量，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x0206, QByteArray(), "getWiredVolume");
}

void XdcController::setWiredVolume(uint8_t index)
{
    if (index >= m_volumeSettings.wiredMaxVolume) {
        qWarning() << "有线音量索引超出范围，最大值:" << m_volumeSettings.wiredMaxVolume - 1;
        emit operationResult(m_hostAddress, "setWiredVolume", false, "音量索引超出范围");
        return;
    }

    qDebug().noquote() << QString("XdcController: 设置有线音量，地址：%1，索引：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(index);
    QByteArray payload;
    payload.append(static_cast<char>(index));
     sendCommand(0x01, 0x0106, payload, "setWiredVolume");
}

void XdcController::handleWiredVolumeResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.size() < 2) {
        qWarning() << "有线音量响应数据长度不足";
        return;
    }

    uint8_t currentIndex = static_cast<uint8_t>(frame.payload.at(0));
    uint8_t maxCount = static_cast<uint8_t>(frame.payload.at(1));

    m_volumeSettings.wiredVolume = currentIndex;
    m_volumeSettings.wiredMaxVolume = maxCount;

    notifyDataChange(DataType::Setting, "wiredVolume", currentIndex);
    notifyDataChange(DataType::Info, "wiredMaxVolume", maxCount);

    qDebug().noquote() << QString("XdcController：有线音量：当前索引=%1，最大档位=%2")
                              .arg(currentIndex).arg(maxCount);
}

void XdcController::getAntennaVolume()
{
    qDebug().noquote() << QString("XdcController: 获取天线盒音量，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x0207, QByteArray(), "getAntennaVolume");
}

void XdcController::setAntennaVolume(uint8_t index)
{
    if (index >= m_volumeSettings.antennaMaxVolume) {
        qWarning() << "天线盒音量索引超出范围，最大值:" << m_volumeSettings.antennaMaxVolume - 1;
        emit operationResult(m_hostAddress, "setAntennaVolume", false, "音量索引超出范围");
        return;
    }

    qDebug().noquote() << QString("XdcController: 设置天线盒音量，地址：%1，索引：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(index);
    QByteArray payload;
    payload.append(static_cast<char>(index));
    sendCommand(0x01, 0x0107, payload, "setAntennaVolume");
}

void XdcController::handleAntennaVolumeResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.size() < 2) {
        qWarning() << "天线盒音量响应数据长度不足";
        return;
    }

    uint8_t currentIndex = static_cast<uint8_t>(frame.payload.at(0));
    uint8_t maxCount = static_cast<uint8_t>(frame.payload.at(1));

    m_volumeSettings.antennaVolume = currentIndex;
    m_volumeSettings.antennaMaxVolume = maxCount;

    notifyDataChange(DataType::Setting, "antennaVolume", currentIndex);
    notifyDataChange(DataType::Info, "antennaMaxVolume", maxCount);

    qDebug().noquote() << QString("XdcController：天线盒音量：当前索引=%1，最大档位=%2")
                              .arg(currentIndex).arg(maxCount);
}

// ==================== 分组3：发言相关功能 ====================
void XdcController::getSpeechMode()
{
    qDebug().noquote() << QString("XdcController: 获取发言模式，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x0208, QByteArray(), "getSpeechMode");
}

void XdcController::setSpeechMode(uint8_t mode)
{
    qDebug().noquote() << QString("XdcController: 设置发言模式，地址：%1，模式：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(mode);
    QByteArray payload;
    payload.append(static_cast<char>(mode));
     sendCommand(0x01, 0x0108, payload, "setSpeechMode");
}

void XdcController::handleSpeechModeResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.isEmpty()) return;

    uint8_t mode = static_cast<uint8_t>(frame.payload.at(0));
    m_speechSettings.speechMode = static_cast<SpeechMode>(mode);

    notifyDataChange(DataType::Setting, "speechMode", mode);

    QString modeStr = (mode == 0) ? "FIFO" : "SelfLock";
    qDebug().noquote() << QString("XdcController：发言模式：%1").arg(modeStr);
}

void XdcController::getMaxSpeechCount()
{
    qDebug().noquote() << QString("XdcController: 获取最大发言数量，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x0209, QByteArray(), "getMaxSpeechCount");
}

void XdcController::setMaxSpeechCount(uint8_t count)
{
    if (count < 1 || count > m_speechSettings.hardwareMaxSpeech) {
        qWarning() << "发言数量超出范围，有效范围: 1-" << m_speechSettings.hardwareMaxSpeech;
        emit operationResult(m_hostAddress, "setMaxSpeechCount", false, "发言数量超出范围");
        return;
    }

    qDebug().noquote() << QString("XdcController: 设置最大发言数量，地址：%1，数量：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(count);
    QByteArray payload;
    payload.append(static_cast<char>(count));
    sendCommand(0x01, 0x0109, payload, "setMaxSpeechCount");
}

void XdcController::handleMaxSpeechCountResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.size() < 2) {
        qWarning() << "最大发言数量响应数据长度不足";
        return;
    }

    uint8_t currentCount = static_cast<uint8_t>(frame.payload.at(0));
    uint8_t maxCount = static_cast<uint8_t>(frame.payload.at(1));

    m_speechSettings.maxSpeechCount = currentCount;
    m_speechSettings.hardwareMaxSpeech = maxCount;

    notifyDataChange(DataType::Setting, "maxSpeechCount", currentCount);
    notifyDataChange(DataType::Info, "hardwareMaxSpeech", maxCount);

    qDebug().noquote() << QString("XdcController：最大发言数量：当前=%1，硬件最大=%2")
                              .arg(currentCount).arg(maxCount);
}

void XdcController::getCurrentWirelessSpeakerId()
{
    qDebug().noquote() << QString("XdcController: 获取当前无线发言ID，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x020E, QByteArray(), "getCurrentWirelessSpeakerId");
}

void XdcController::handleCurrentWirelessSpeakerIdResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    // 响应格式：多个2字节的单元ID，最多8个
    int count = frame.payload.size() / 2;
    if (count > 0) {
        uint16_t speakerId = (static_cast<uint8_t>(frame.payload.at(0)) << 8) |
                             static_cast<uint8_t>(frame.payload.at(1));
        m_speechSettings.currentWirelessSpeakerId = speakerId;
        notifyDataChange(DataType::Info, "currentWirelessSpeakerId", speakerId);
        emit currentSpeakerIdUpdated(m_hostAddress, "wireless", speakerId);
        qDebug().noquote() << QString("XdcController：当前无线发言ID：0x%1")
                                  .arg(speakerId, 4, 16, QChar('0'));
    } else {
        m_speechSettings.currentWirelessSpeakerId = 0;
        notifyDataChange(DataType::Info, "currentWirelessSpeakerId", 0);
    }
}

void XdcController::getCurrentWiredSpeakerId()
{
    qDebug().noquote() << QString("XdcController: 获取当前有线发言ID，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x020F, QByteArray(), "getCurrentWiredSpeakerId");
}

void XdcController::handleCurrentWiredSpeakerIdResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    int count = frame.payload.size() / 2;
    if (count > 0) {
        uint16_t speakerId = (static_cast<uint8_t>(frame.payload.at(0)) << 8) |
                             static_cast<uint8_t>(frame.payload.at(1));
        m_speechSettings.currentWiredSpeakerId = speakerId;
        notifyDataChange(DataType::Info, "currentWiredSpeakerId", speakerId);
        emit currentSpeakerIdUpdated(m_hostAddress, "wired", speakerId);
        qDebug().noquote() << QString("XdcController：当前有线发言ID：0x%1")
                                  .arg(speakerId, 4, 16, QChar('0'));
    } else {
        m_speechSettings.currentWiredSpeakerId = 0;
        notifyDataChange(DataType::Info, "currentWiredSpeakerId", 0);
    }
}

void XdcController::getWirelessAudioPath()
{
    qDebug().noquote() << QString("XdcController: 获取无线音频路径，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x020D, QByteArray(), "getWirelessAudioPath");
}

void XdcController::setWirelessAudioPath(uint8_t path)
{
    qDebug().noquote() << QString("XdcController: 设置无线音频路径，地址：%1，路径：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(path);
    QByteArray payload;
    payload.append(static_cast<char>(path));
    sendCommand(0x01, 0x010D, payload, "setWirelessAudioPath");
}

void XdcController::handleWirelessAudioPathResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.isEmpty()) return;

    uint8_t path = static_cast<uint8_t>(frame.payload.at(0));
    m_speechSettings.wirelessAudioPath = static_cast<WirelessAudioPath>(path);

    notifyDataChange(DataType::Setting, "wirelessAudioPath", path);

    QString pathStr = (path == 0) ? "主机" : "天线盒";
    qDebug().noquote() << QString("XdcController：无线音频路径：%1").arg(pathStr);
}

// ==================== 分组4：摄像跟踪相关功能 ====================
void XdcController::getCameraProtocol()
{
    qDebug().noquote() << QString("XdcController: 获取摄像跟踪协议，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x020A, QByteArray(), "getCameraProtocol");
}

void XdcController::setCameraProtocol(uint8_t protocol)
{
    qDebug().noquote() << QString("XdcController: 设置摄像跟踪协议，地址：%1，协议：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(protocol);
    QByteArray payload;
    payload.append(static_cast<char>(protocol));
    sendCommand(0x01, 0x010A, payload, "setCameraProtocol");
}

void XdcController::handleCameraProtocolResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.isEmpty()) return;

    uint8_t protocol = static_cast<uint8_t>(frame.payload.at(0));
    m_cameraSettings.protocol = static_cast<CameraProtocol>(protocol);

    notifyDataChange(DataType::Setting, "cameraProtocol", protocol);

    QString protocolStr;
    switch (protocol) {
    case 0: protocolStr = "无"; break;
    case 1: protocolStr = "VISCA"; break;
    case 2: protocolStr = "PELCO_D"; break;
    case 3: protocolStr = "PELCO_P"; break;
    default: protocolStr = "未知";
    }
    qDebug().noquote() << QString("XdcController：摄像跟踪协议：%1").arg(protocolStr);
}

void XdcController::getCameraAddress()
{
    qDebug().noquote() << QString("XdcController: 获取摄像跟踪地址，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
     sendCommand(0x01, 0x020B, QByteArray(), "getCameraAddress");
}

void XdcController::setCameraAddress(uint8_t address)
{
    qDebug().noquote() << QString("XdcController: 设置摄像跟踪地址，地址：%1，摄像机地址：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(address);
    QByteArray payload;
    payload.append(static_cast<char>(address));
    sendCommand(0x01, 0x010B, payload, "setCameraAddress");
}

void XdcController::handleCameraAddressResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.isEmpty()) return;

    uint8_t address = static_cast<uint8_t>(frame.payload.at(0));
    m_cameraSettings.address = address;

    notifyDataChange(DataType::Setting, "cameraAddress", address);
    qDebug().noquote() << QString("XdcController：摄像跟踪地址：%1").arg(address);
}

void XdcController::getCameraBaudrate()
{
    qDebug().noquote() << QString("XdcController: 获取摄像跟踪波特率，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x020C, QByteArray(), "getCameraBaudrate");
}

void XdcController::setCameraBaudrate(uint8_t baudrate)
{
    qDebug().noquote() << QString("XdcController: 设置摄像跟踪波特率，地址：%1，波特率：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(baudrate);
    QByteArray payload;
    payload.append(static_cast<char>(baudrate));
    sendCommand(0x01, 0x010C, payload, "setCameraBaudrate");
}

void XdcController::handleCameraBaudrateResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.isEmpty()) return;

    uint8_t baudrate = static_cast<uint8_t>(frame.payload.at(0));
    m_cameraSettings.baudrate = static_cast<CameraBaudrate>(baudrate);

    notifyDataChange(DataType::Setting, "cameraBaudrate", baudrate);

    QString baudrateStr;
    switch (baudrate) {
    case 0: baudrateStr = "2400bps"; break;
    case 1: baudrateStr = "4800bps"; break;
    case 2: baudrateStr = "9600bps"; break;
    case 3: baudrateStr = "115200bps"; break;
    default: baudrateStr = "未知";
    }
    qDebug().noquote() << QString("XdcController：摄像跟踪波特率：%1").arg(baudrateStr);
}

// ==================== 分组7：系统时间相关功能 ====================
void XdcController::getSystemDateTime()
{
    qDebug().noquote() << QString("XdcController: 获取系统时间，地址：%1")
                              .arg(formatAddressHex(m_hostAddress));
    sendCommand(0x01, 0x0204, QByteArray(), "getSystemDateTime");
}

void XdcController::setSystemDateTime(uint32_t utcTime)
{
    qDebug().noquote() << QString("XdcController: 设置系统时间，地址：%1，UTC时间戳：%2")
                              .arg(formatAddressHex(m_hostAddress)).arg(utcTime);
    QByteArray payload;
    // UTC时间戳，大端模式
    payload.append(static_cast<char>((utcTime >> 24) & 0xFF));
    payload.append(static_cast<char>((utcTime >> 16) & 0xFF));
    payload.append(static_cast<char>((utcTime >> 8) & 0xFF));
    payload.append(static_cast<char>(utcTime & 0xFF));
    sendCommand(0x01, 0x0104, payload, "setSystemDateTime");
}

void XdcController::handleSystemDateTimeResponse(const ProtocolProcessor::ParsedFrameData& frame)
{
    if (frame.payload.size() < 4) {
        qWarning() << "系统时间响应数据长度不足";
        return;
    }

    uint32_t utcTime = (static_cast<uint8_t>(frame.payload.at(0)) << 24) |
                       (static_cast<uint8_t>(frame.payload.at(1)) << 16) |
                       (static_cast<uint8_t>(frame.payload.at(2)) << 8) |
                       static_cast<uint8_t>(frame.payload.at(3));

    m_systemDateTime = QDateTime::fromSecsSinceEpoch(utcTime);

    notifyDataChange(DataType::Setting, "systemDateTime", m_systemDateTime);
    emit systemDateTimeUpdated(m_hostAddress, m_systemDateTime);

    qDebug().noquote() << QString("XdcController：系统时间：%1")
                              .arg(m_systemDateTime.toString("yyyy-MM-dd hh:mm:ss"));
}

// ==================== 通用设置响应处理 ====================
void XdcController::handleSetResponse(const ProtocolProcessor::ParsedFrameData& frame, const QString& operation)
{
    // 设置命令的响应，通常表示操作成功
    qDebug().noquote() << QString("XdcController：设置命令响应，CMD：0x%1，操作：%2")
                              .arg(QString::number(frame.command, 16).toUpper(), operation);
    emit operationResult(m_hostAddress, operation, true, "操作成功");
}

